#pragma once

#include <deque>
#include <istream>
#include <list>
#include <map>
#include <ostream>
#include <set>
#include <string>
#include <vector>
using namespace std;

class InvertedIndex {
   public:
    void Add(string document);
    const std::vector<std::pair<size_t, size_t>>* Lookup(const string_view& word) const;
    size_t getDocsSize() const { return docs.size(); }
    const string& GetDocument(size_t id) const { return docs[id]; }

   private:
    map<string_view, std::vector<std::pair<size_t, size_t>>> index;
    deque<string> docs;
};

class SearchServer {
   public:
    SearchServer() = default;
    explicit SearchServer(istream& document_input);
    void UpdateDocumentBase(istream& document_input);
    void AddQueriesStream(istream& query_input, ostream& search_results_output);

   private:
    InvertedIndex index;
};
