#include "search_server.h"
#include "iterator_range.h"

#include <algorithm>
#include <iostream>
#include <iterator>
#include <sstream>

void removeSpaces(std::string_view& str) {
    while (std::isspace(str[0])) {
        str.remove_prefix(1);
    }
}

vector<string_view> SplitIntoWords(const string& line) {
    vector<string_view> result;
    std::string_view words(line);
    while (!words.empty()) {
        removeSpaces(words);

        if (words.empty()) {
            break;
        }
        size_t wordLen = words.find(' ');
        result.push_back(words.substr(0, wordLen));

        if (wordLen == words.npos) {
            break;
        } else {
            words.remove_prefix(wordLen);
        }
    }

    return result;
}

SearchServer::SearchServer(istream& document_input) { UpdateDocumentBase(document_input); }

void SearchServer::UpdateDocumentBase(istream& document_input) {
    InvertedIndex new_index;

    for (string current_document; getline(document_input, current_document);) {
        new_index.Add(move(current_document));
    }

    index = move(new_index);
}

void SearchServer::AddQueriesStream(istream& query_input, ostream& search_results_output) {
    std::vector<std::pair<size_t, size_t>> search_results(index.getDocsSize());
    for (string current_query; getline(query_input, current_query);) {
        const auto words = SplitIntoWords(current_query);
        //        search_results.fill({0,0});
        search_results.assign(search_results.size(), {0, 0});

        for (const auto& word : words) {
            auto hitcounts = index.Lookup(word);
            if (hitcounts == nullptr) {
                continue;
            }
            for (int i = 0; i < hitcounts->size(); ++i) {
                //                if (hitcounts->size() > docId) {
                size_t docId = (*hitcounts)[i].first;
                size_t hitcount = (*hitcounts)[i].second;
                search_results[docId].first = docId;
                search_results[docId].second += hitcount;
                //                }
            }
        }

        int middle = std::min((size_t)5, search_results.size() - 1);
        partial_sort(begin(search_results), begin(search_results) + middle, end(search_results),
                     [](pair<size_t, size_t> lhs, pair<size_t, size_t> rhs) {
                         int64_t lhs_docid = lhs.first;
                         auto lhs_hit_count = lhs.second;
                         int64_t rhs_docid = rhs.first;
                         auto rhs_hit_count = rhs.second;
                         return make_pair(lhs_hit_count, -lhs_docid) >
                                make_pair(rhs_hit_count, -rhs_docid);
                     });

        search_results_output << current_query << ':';
        for (auto [docid, hitcount] : Head(search_results, 5)) {
            if (hitcount > 0) {
                search_results_output << " {"
                                      << "docid: " << docid << ", "
                                      << "hitcount: " << hitcount << '}';
            }
        }
        search_results_output << endl;
    }
}

void InvertedIndex::Add(string document) {
    const size_t docid = docs.size();
    docs.push_back(std::move(document));
    for (const auto& word : SplitIntoWords(docs.back())) {
        auto& hitcounts = index[word];
        if (hitcounts.size() > docid) {
            ++hitcounts[docid].second;
        } else {
            hitcounts.reserve(50000);
            hitcounts.emplace_back(docid, 1);
        }
    }
}

const std::vector<std::pair<size_t, size_t>>* InvertedIndex::Lookup(const string_view& word) const {
    if (auto it = index.find(word); it != index.end()) {
        return &it->second;
    } else {
        return nullptr;
    }
}
